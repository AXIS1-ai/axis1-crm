import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import test from "node:test";

const source = fs.readFileSync(new URL("../script.js", import.meta.url), "utf8");
const prefix = source.split('$("clientForm").addEventListener')[0];

function createHarness(seed = {}, options = {}) {
  const storage = new Map(Object.entries(seed));
  const elements = new Map();
  const element = (id) => {
    if (!elements.has(id)) elements.set(id, {
      id, value: "", textContent: "", innerHTML: "", open: false,
      options: [], classList: { add() {}, remove() {}, toggle() {} },
      showModal() { this.open = true; }, close() { this.open = false; },
      querySelectorAll() { return []; }, reset() {}, appendChild() {},
      remove() {}, click() {}, focus() {}, setAttribute() {},
      addEventListener() {}, style: {}
    });
    return elements.get(id);
  };
  const sandbox = {
    console, Blob, URL, Uint8Array, Math, Date: options.Date || Date, JSON, RegExp,
    localStorage: {
      getItem(key) {
        if (options.failGetItem?.(key)) throw new Error("SecurityError sintético");
        return storage.has(key) ? storage.get(key) : null;
      },
      setItem(key, value) {
        if (options.failSetItem?.(key, String(value))) throw new Error("QuotaExceededError sintético");
        storage.set(key, String(value));
      },
      removeItem(key) {
        if (options.failRemoveItem?.(key)) throw new Error("SecurityError de remoção sintético");
        storage.delete(key);
      }
    },
    document: {
      getElementById: element,
      querySelectorAll() { return []; },
      createElement() { return element(`created-${elements.size}`); },
      body: { appendChild() {} }
    },
    window: {
      clearTimeout, setTimeout, confirm: () => true,
      scrollTo() {}, open() {}, alert() {},
      history: { replaceState() {} },
      location: { search: "", pathname: "/" }
    },
    navigator: { clipboard: { writeText: async () => {} } },
    URLSearchParams,
    setTimeout, clearTimeout,
    FileReader: class {},
    prompt: () => ""
  };
  vm.createContext(sandbox);
  vm.runInContext(`${prefix}
    render = () => {};
    showHistory = () => {};
    toast = (message) => { globalThis.__lastToast = message; };
    globalThis.__api = {
      constants: { SCHEMA_VERSION, STORAGE_KEY, SNAPSHOT_KEY, TRASH_KEY, GOAL_KEY, RECEIPT_COUNTER_KEY, FINANCIAL_REPORTS_KEY, PERSISTENCE_JOURNAL_KEY, LEGACY_KEYS, MAX_SNAPSHOTS },
      normalizeRecord, validateRecord, duplicateMatch, upsertRecord, moveCommercialStage,
      deleteRecord, restoreFromTrash, registerPayment, getRecordReceivables,
      getFinancialStatus, buildMonthlyFinancialReport, ensureReceipt, createReceiptPdf,
      backupPayload, parseBackup, mergeRecordCollections, mergeMostComplete,
      performImport, restoreSnapshot,
      setRecords(value) { records = value.map(normalizeRecord); },
      setRawRecords(value) { records = value; },
      getRecords() { return cloneData(records); },
      getTrash() { return cloneData(trash); },
      getSnapshots,
      setPendingImport(backup) { pendingImport = { fileName: "synthetic.json", backup }; },
      addSnapshot(reason) { pushSnapshot(reason); },
      persistData,
      getPersistenceWarning() { return persistenceWarning; },
      storageKeys() { return [...storage.keys()]; }
    };
  `, sandbox);
  return { api: sandbox.__api, sandbox, storage, elements };
}

const sample = (overrides = {}) => ({
  id: "synthetic-client-1", name: "Cliente Sintético", company: "Empresa Fictícia",
  phone: "16987654321", email: "teste@example.invalid", status: "Ativo",
  plan: "Essencial", value: 1000, paymentType: "1x", dueDate: "2026-06-15",
  commercialStage: "Em contato", ...overrides
});

test("chaves e versão de esquema existentes permanecem identificadas", () => {
  const { api } = createHarness();
  assert.equal(api.constants.SCHEMA_VERSION, 5);
  assert.deepEqual(Array.from(api.constants.LEGACY_KEYS), [
    "axis1_crm_v2_insano", "axis1_crm_definitivo_v1", "axis1_crm_integrado_v1",
    "axis1_crm_records", "axis1_crm_clientes", "axis1_clientes", "crmAxis1",
    "clientesAxis1", "axis1-crm", "crm"
  ]);
  assert.equal(api.constants.MAX_SNAPSHOTS, 10);
});

test("normaliza contato, aceita cadastro sintético válido e bloqueia duplicidade", () => {
  const { api } = createHarness();
  const record = api.normalizeRecord(sample({ phone: "+55 (16) 98765-4321", email: " TESTE@EXAMPLE.INVALID " }));
  assert.equal(record.phone, "16987654321");
  assert.equal(record.email, "teste@example.invalid");
  assert.equal(api.validateRecord(record), "");
  api.setRecords([record]);
  const duplicate = api.normalizeRecord(sample({ id: "another", phone: "5516987654321", name: "Outro registro" }));
  assert.match(api.validateRecord(duplicate), /mesmo WhatsApp/);
});

test("cadastro e avanço do Pipeline atualizam estado e snapshot", () => {
  const { api } = createHarness();
  api.upsertRecord(api.normalizeRecord(sample({ status: "Lead", commercialStage: "Novo lead" })));
  assert.equal(api.getRecords().length, 1);
  assert.equal(api.getSnapshots().length, 1);
  api.moveCommercialStage("synthetic-client-1", 1);
  assert.equal(api.getRecords()[0].commercialStage, "Em contato");
  assert.equal(api.getRecords()[0].commercialHistory.length > 0, true);
});

test("exclusão e restauração da lixeira preservam cadastro sintético", () => {
  const { api, sandbox } = createHarness();
  api.setRecords([sample()]);
  api.deleteRecord("synthetic-client-1");
  assert.equal(api.getRecords().length, 0);
  assert.equal(api.getTrash().length, 1);
  api.restoreFromTrash("synthetic-client-1");
  assert.equal(api.getRecords().length, 1);
  assert.equal(api.getTrash().length, 0);
  assert.equal(sandbox.__lastToast, "Cadastro restaurado.");
});

test("pagamento parcial e quitação avaliam status em duas datas controladas", () => {
  const fixedNow = new Date("2026-06-20T12:00:00.000Z");
  const NativeDate = Date;
  class ControlledDate extends NativeDate {
    constructor(...args) { super(...(args.length ? args : [fixedNow])); }
    static now() { return fixedNow.getTime(); }
  }
  const { api } = createHarness({ axis1_crm_v2_insano: "[]" }, { Date: ControlledDate });
  // O teste congela o relógio do contexto para o vencimento seguinte ser 15/07/2026.
  api.setRecords([sample({ dueDate: "2026-06-15" })]);
  const receivable = api.getRecordReceivables(api.getRecords()[0])[0];
  api.registerPayment("synthetic-client-1", 1, {
    amount: 400, paidAt: "2026-06-15", paymentMethod: "Pix",
    referencePeriod: "Junho/2026", notes: "Parcial sintético",
    cycleId: receivable.cycleId, balanceDueDate: "2026-06-25"
  });
  let record = api.getRecords()[0];
  assert.equal(record.paymentHistory[0].isPartial, true);
  assert.equal(record.openBalances[0].remainingAmount, 600);
  assert.equal(api.getFinancialStatus(record), "Parcialmente pago");
  const open = api.getRecordReceivables(record)[0];
  api.registerPayment("synthetic-client-1", 1, {
    amount: 600, paidAt: "2026-06-20", paymentMethod: "Pix",
    referencePeriod: "Junho/2026", notes: "Quitação sintética",
    cycleId: open.cycleId, balanceDueDate: ""
  });
  record = api.getRecords()[0];
  assert.equal(record.openBalances.length, 0);
  assert.equal(record.paymentHistory.length, 2);
  // Baseline atual: quitado o vencimento, o próximo ciclo vence e pode marcar atraso.
  assert.equal(record.dueDate, "2026-07-15");
  assert.equal(api.getFinancialStatus(record), "Em dia");
  // Com a mesma data atual e vencimento subsequente deliberadamente passado, atraso é legítimo.
  const overdue = api.normalizeRecord({ ...record, dueDate: "2026-06-19", openBalances: [] });
  assert.equal(api.getFinancialStatus(overdue), "Em atraso");
  assert.equal(record.financialHistory.length, 2);
});

test("recibo parcial/final recebe números distintos e PDF começa com assinatura válida", () => {
  const { api } = createHarness();
  const record = api.normalizeRecord(sample({ paymentHistory: [
    { id: "payment-partial", paidAt: "2026-06-15", amount: 400, installment: "Mensal", previousDueDate: "2026-06-15", paymentMethod: "Pix", isPartial: true, balanceRemaining: 600 },
    { id: "payment-final", paidAt: "2026-06-20", amount: 600, installment: "Mensal", previousDueDate: "2026-06-15", paymentMethod: "Pix", isPartial: false }
  ] }));
  api.setRecords([record]);
  const result = api.getRecords()[0];
  const partial = api.ensureReceipt(result, result.paymentHistory[0]);
  const same = api.ensureReceipt(result, result.paymentHistory[0]);
  const final = api.ensureReceipt(result, result.paymentHistory[1]);
  assert.equal(partial.receiptNumber, same.receiptNumber);
  assert.notEqual(partial.receiptNumber, final.receiptNumber);
  assert.equal(result.receipts.length, 2);
  return api.createReceiptPdf(partial).arrayBuffer().then((buffer) => {
    assert.equal(new TextDecoder().decode(buffer.slice(0, 8)), "%PDF-1.4");
  });
});

test("relatório mensal agrega ciclos e pagamentos; registra duplicidade de ciclo atual", () => {
  const { api } = createHarness();
  api.setRecords([sample({ paymentHistory: [
    { id: "payment-1", paidAt: "2026-06-16", amount: 250, installment: "Mensal", previousDueDate: "2026-06-15", paymentMethod: "Pix", isPartial: true, balanceRemaining: 750 }
  ], openBalances: [{ id: "balance-1", cycleId: "cycle-1", installment: 1, dueDate: "2026-06-15", expectedAmount: 1000, paidAmount: 250, remainingAmount: 750, balanceDueDate: "2026-06-25" }] })]);
  const report = api.buildMonthlyFinancialReport(2026, 5);
  // Baseline atual: adiciona ciclo inferido do pagamento (R$ 1.000) e saldo corrente (R$ 250).
  assert.equal(report.expected, 1250);
  assert.equal(report.received, 250);
  assert.equal(report.open, 750);
  assert.equal(report.partialCount, 1);
  assert.equal(report.payments.length, 1);
});

test("backup completo round-trip e formato legado continuam aceitos", () => {
  const { api } = createHarness();
  api.setRecords([sample()]);
  const payload = api.backupPayload();
  assert.equal(payload.schemaVersion, 5);
  for (const key of ["exportedAt", "records", "trash", "monthlyGoal", "snapshots", "receiptCounters", "financialReports"]) assert.ok(key in payload);
  const parsed = api.parseBackup(payload);
  assert.equal(parsed.records.length, 1);
  assert.equal(api.parseBackup([{ nome: "Lead Legado Sintético", telefone: "16911112222" }]).records[0].name, "Lead Legado Sintético");
});

test("restauração de snapshot volta ao estado salvo e cria cópia de segurança", () => {
  const { api } = createHarness();
  api.setRecords([sample()]);
  api.addSnapshot("estado anterior sintético");
  const snapshot = api.getSnapshots()[0];
  api.setRecords([sample({ name: "Estado atual alterado" })]);
  api.restoreSnapshot(snapshot.id);
  assert.equal(api.getRecords()[0].name, "Cliente Sintético");
  assert.equal(api.getSnapshots().length, 2);
});

test("snapshots retêm no máximo dez estados", () => {
  const { api } = createHarness();
  for (let index = 0; index < 12; index += 1) api.addSnapshot(`snapshot sintético ${index}`);
  assert.equal(api.getSnapshots().length, 10);
});

test("importação de substituição preserva confirmação, dados e snapshot de segurança", () => {
  const { api } = createHarness();
  api.setRecords([sample({ id: "before-import", name: "Antes da importação" })]);
  api.setPendingImport(api.parseBackup({
    schemaVersion: 5,
    records: [sample({ id: "incoming-record", name: "Backup sintético" })],
    trash: [], monthlyGoal: 500, snapshots: [], receiptCounters: {}, financialReports: []
  }));
  api.performImport("replace");
  assert.equal(api.getRecords()[0].name, "Backup sintético");
  assert.equal(api.getSnapshots().length >= 1, true);
});

test("importação mesclada mantém um único cadastro duplicado", () => {
  const { api } = createHarness();
  api.setRecords([api.normalizeRecord(sample({ company: "Empresa preservada" }))]);
  api.setPendingImport(api.parseBackup({
    schemaVersion: 5,
    records: [sample({ id: "backup-id", phone: "5516987654321", email: "", notes: "Complemento do backup" })],
    trash: [], monthlyGoal: 0, snapshots: [], receiptCounters: {}, financialReports: []
  }));
  api.performImport("merge");
  assert.equal(api.getRecords().length, 1);
  assert.equal(api.getRecords()[0].company, "Empresa preservada");
  assert.equal(api.getRecords()[0].notes, "Complemento do backup");
});

test("mesclagem evita duplicidade do mesmo contato e preserva campos preenchidos", () => {
  const { api } = createHarness();
  const current = api.normalizeRecord(sample({ company: "Empresa Fictícia" }));
  const incoming = api.normalizeRecord(sample({ id: "backup-id", phone: "5516987654321", email: "", company: "", notes: "Observação importada" }));
  const stats = { imported: 0, ignored: 0, merged: 0 };
  const merged = api.mergeRecordCollections([current], [incoming], stats);
  assert.equal(merged.length, 1);
  assert.equal(merged[0].company, "Empresa Fictícia");
  assert.equal(merged[0].notes, "Observação importada");
  assert.equal(stats.merged, 1);
});

test("gravação parcial é revertida, verificada e não deixa operação como concluída", () => {
  let injected = false;
  const { api, storage } = createHarness({}, {
    failSetItem: (key) => {
      if (key === "axis1_crm_v3_financial_reports" && !injected) {
        injected = true;
        return true;
      }
      return false;
    }
  });
  storage.set("axis1_crm_v2_insano", "[]");
  storage.set("axis1_crm_v2_trash", "[]");
  storage.set("axis1_crm_v2_goal", "0");
  storage.set("axis1_crm_v3_receipt_counters", "{}");
  storage.set("axis1_crm_v3_financial_reports", "[]");
  storage.set("axis1_crm_v2_snapshots", "[]");
  api.setRecords([sample()]);
  assert.throws(() => api.persistData(), /estado anterior foi restaurado/);
  assert.equal(storage.get("axis1_crm_v2_insano"), "[]");
  assert.equal(storage.get("axis1_crm_v2_trash"), "[]");
  assert.equal(storage.get("axis1_crm_v3_financial_reports"), "[]");
  assert.equal(storage.has(api.constants.PERSISTENCE_JOURNAL_KEY), false);
  assert.match(api.getPersistenceWarning(), /operação não foi concluída/);
});

test("gravação íntegra mantém schema v5 e todas as chaves operacionais", () => {
  const { api, storage } = createHarness();
  api.setRecords([sample()]);
  api.addSnapshot("estado sintético de integridade");
  api.persistData();
  for (const key of [
    "axis1_crm_v2_insano", "axis1_crm_v2_trash", "axis1_crm_v2_goal",
    "axis1_crm_v2_snapshots", "axis1_crm_v3_receipt_counters", "axis1_crm_v3_financial_reports"
  ]) assert.equal(storage.has(key), true, `chave ausente: ${key}`);
  assert.equal(storage.has("axis1_crm_v5_persistence_journal"), false);
  const savedRecords = JSON.parse(storage.get("axis1_crm_v2_insano"));
  assert.equal(savedRecords[0].id, "synthetic-client-1");
  assert.equal(api.constants.SCHEMA_VERSION, 5);
});

test("diário interrompido recupera o estado anterior na inicialização", () => {
  const previous = {
    axis1_crm_v2_insano: "[]",
    axis1_crm_v2_trash: "[]",
    axis1_crm_v2_goal: "0",
    axis1_crm_v3_receipt_counters: "{}",
    axis1_crm_v3_financial_reports: "[]",
    axis1_crm_v2_snapshots: "[]"
  };
  const seed = {
    ...previous,
    axis1_crm_v2_insano: JSON.stringify([sample({ name: "estado parcial" })]),
    axis1_crm_v5_persistence_journal: JSON.stringify({ schemaVersion: 5, createdAt: "2026-11-06T12:00:00Z", previous })
  };
  const { api, storage } = createHarness(seed);
  assert.equal(storage.get("axis1_crm_v2_insano"), "[]");
  assert.equal(storage.has(api.constants.PERSISTENCE_JOURNAL_KEY), false);
  assert.match(api.getPersistenceWarning(), /gravação interrompida foi revertida/);
});

test("erro de leitura bloqueia novas gravações e erro de validação não persiste estado", () => {
  const unreadable = createHarness({}, { failGetItem: (key) => key === "axis1_crm_v5_persistence_journal" });
  assert.throws(() => unreadable.api.persistData(), /Nenhuma alteração nova será salva/);
  assert.equal(unreadable.storage.has("axis1_crm_v2_insano"), false);

  const { api, storage } = createHarness();
  api.setRawRecords([{ name: "sem id e sem históricos" }]);
  assert.throws(() => api.persistData(), /cadastro sem identificador ou com histórico inválido/);
  assert.equal(storage.has("axis1_crm_v2_insano"), false);
});

